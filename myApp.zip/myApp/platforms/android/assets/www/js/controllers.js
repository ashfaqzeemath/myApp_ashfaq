angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout)/*$scope, $ionicModal, $timeout*/ {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});
    
        
})//Appctrl end

.controller('usrLoginCtrl', function($scope, $ionicModal , $timeout) {
      // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.usrlogin = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  }; //login controll end
    
})


.controller('usrsignupCtrl', function($scope, $ionicModal, $timeout, UserModel) {
    
  // Form data for the signup modal
  $scope.signupData = {};

    $scope.test = function(text) {
      alert(text);
    } 
    
  // Create the signup modal that we will use later
  $ionicModal.fromTemplateUrl('templates/signup.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });    
    
  // Triggered in the signup modal to close it
  $scope.closeSignup = function() {
    $scope.modal.hide();
  };

  // Open the signup modal
  $scope.usrsignup = function() {
    $scope.modal.show();
  };

  // Perform the signup action when the user submits the signup form
  $scope.doSignup = function() {
    console.log('Doing signup', $scope.signupData);

    // Simulate a signup delay. Remove this and replace with your signup
    // code if using a login system
    $timeout(function() {
      $scope.CloseSignup();
    }, 1000);
  };
    
   $scope.create = function(signupData){
       UserModel.create(signupData).then(function(){
           $scope.test('wada wada');
           $scope.closeSignup();
       })
   };
    
    /*
    function create(object) {
    UserModel.create(object)
        .then(function (result) {
          $scope.CloseSignup();
        });
    };*/
    
})//SignupCtrl end

.controller('PlaylistsCtrl', function($scope) {
  $scope.playlists = [
            { title: 'Reggae', id: 1 },
            { title: 'Chill', id: 2 },
            { title: 'Dubstep', id: 3 },
            { title: 'Indie', id: 4 },
            { title: 'Rap', id: 5 },
            { title: 'Cowbell', id: 6 }
  ];
})

.controller('PlaylistCtrl', function($scope, $stateParams) {
    });
